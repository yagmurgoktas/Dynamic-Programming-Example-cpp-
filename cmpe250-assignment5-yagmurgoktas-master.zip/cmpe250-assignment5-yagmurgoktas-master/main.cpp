/*
Student Name:
Student Number:
Project Number: 5
Compile Status: [SUCCESS/FAIL]
Running Status: [SUCCESS/FAIL]
Notes: Anything you want to say about your code that will be helpful in the grading process.
*/

#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>

using namespace std;
long int max(long int lookup[],int k,int M,vector<long int> &chocolates,vector<int> &sum){
    if(lookup[k]==NULL){
        if(k==1) {
            lookup[1] = chocolates[0];
        }else if(k<=M){
            lookup[k]=max(lookup,k-1,M,chocolates,sum)+chocolates[k-1];
        }
        else {
          lookup[k]=max(lookup,k-M,M,chocolates,sum)+sum[k-1];
        }
    }
          return lookup[k];

}
int main(int argc, char* argv[]){

    int N;
    int M;

    ifstream inFile(argv[1]);
    ofstream outFile(argv[2]);
    inFile>> N;
    inFile>> M;

    vector<long int> chocolates;
    for (int i = 0; i < N; i++)
    {
        int a;
        inFile >> a;

        chocolates.push_back(a);
    }

    inFile.close();

    sort(chocolates.begin(), chocolates.end());
    vector<int> sum;
    sum.push_back(chocolates[0]);
    long int lookup[N+1];
    for (int p = 0; p < N+1; p++) {
        lookup[p] = NULL;
        if(p<N && p>0) {
            sum.push_back(sum[p-1] + chocolates[p])  ;
        }
    }

    for(int k=1;k<=N;k++) {
        outFile << max(lookup, k, M, chocolates,sum)<< " ";
    }

   cout << "" << endl;

    return 0;
}
